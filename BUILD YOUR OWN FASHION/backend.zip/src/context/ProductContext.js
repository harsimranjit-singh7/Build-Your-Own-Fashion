import React from "react";

const ProductContext = React.createContext();

export default ProductContext;